import React, { useState, useCallback, useEffect } from 'react';
import { themes, FONT } from './styles/theme';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import TimerWidget from './components/TimerWidget';

// Check if running inside Electron
const isElectron = typeof window !== 'undefined' && window.electronAPI;

// Simple hash-based routing for Electron
function useHash() {
  const [hash, setHash] = useState(window.location.hash);
  useEffect(() => {
    const handler = () => setHash(window.location.hash);
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);
  return hash;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [isDark, setIsDark] = useState(false);
  const hash = useHash();

  const toggleTheme = useCallback(() => setIsDark((prev) => !prev), []);
  const theme = isDark ? themes.dark : themes.light;

  const handleLogin = (userData) => setUser(userData);
  const handleLogout = () => setUser(null);

  // If URL hash is /timer-widget, render the floating mini timer
  if (hash === '#/timer-widget') {
    return <TimerWidget theme={theme} isDark={isDark} />;
  }

  // Main app
  if (!user) {
    return <Login onLogin={handleLogin} theme={theme} isDark={isDark} onToggleTheme={toggleTheme} isElectron={isElectron} />;
  }

  return <Dashboard user={user} onLogout={handleLogout} theme={theme} isDark={isDark} onToggleTheme={toggleTheme} isElectron={isElectron} />;
}
