import React from 'react';

export default function ProgressRing({ used, total, theme: t, size = 130 }) {
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const pct = Math.min(used / Math.max(total, 0.01), 1);
  const isOver = used > total;

  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={t.border} strokeWidth="7" opacity=".4" />
      <circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none" stroke={isOver ? t.danger : t.accent}
        strokeWidth="7" strokeDasharray={circ}
        strokeDashoffset={circ * (1 - pct)}
        strokeLinecap="round"
        style={{ transition: 'stroke-dashoffset .7s ease' }}
      />
    </svg>
  );
}
