import React, { useState } from 'react';
import { brand, FONT } from '../styles/theme';
import Logo from './Logo';

export default function Login({ onLogin, theme: t, isDark, onToggleTheme, isElectron }) {
  const [name, setName] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [isNew, setIsNew] = useState(false);
  const [tluVal, setTluVal] = useState('1');
  const [hptVal, setHptVal] = useState('128');

  const handleLogin = async () => {
    if (isElectron) {
      const user = await window.electronAPI.loginUser(name.trim(), pin);
      if (user) { setError(''); onLogin(user); }
      else setError('Name or PIN not found.');
    } else {
      // Fallback for browser dev mode
      if (name.trim().toLowerCase() === 'rishi' && pin === '1234') {
        onLogin({ id: 1, name: 'Rishi', hours_per_tlu: 128, tlu_allocation: 1 });
      } else {
        setError('Name or PIN not found.');
      }
    }
  };

  const handleCreate = async () => {
    if (!name.trim() || pin.length < 4) { setError('Enter name + 4-digit PIN.'); return; }
    if (isElectron) {
      const result = await window.electronAPI.createUser({
        name: name.trim(), pin, hoursPerTlu: +hptVal || 128, tluAllocation: +tluVal || 1,
      });
      if (result.error) { setError(result.error); return; }
      onLogin(result);
    }
  };

  const inputStyle = (focused) => ({
    width: '100%', boxSizing: 'border-box', padding: '13px 16px', fontSize: 17, fontFamily: FONT,
    border: `1.5px solid ${t.border}`, borderRadius: 12, background: t.card, color: t.text, outline: 'none',
  });

  return (
    <div style={{ minHeight: '100vh', background: t.bg, display: 'flex', flexDirection: 'column', fontFamily: FONT }}>
      <div style={{ background: t.hdr, padding: '14px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', WebkitAppRegion: 'drag' }}>
        <Logo isDark={isDark} />
        <button onClick={onToggleTheme} style={{ width: 38, height: 38, borderRadius: 10, border: 'none', cursor: 'pointer', background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(255,255,255,.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', WebkitAppRegion: 'no-drag' }}>
          {isDark
            ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FCD34D" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
            : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
          }
        </button>
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
        <div style={{ width: '100%', maxWidth: 400, background: t.card, borderRadius: 20, padding: '40px 32px', boxShadow: t.shadow, border: `1px solid ${t.border}` }}>
          <div style={{ textAlign: 'center', marginBottom: 28 }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: brand.magenta, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </div>
            <h1 style={{ fontSize: 24, fontWeight: 700, color: t.text, margin: '0 0 4px' }}>{isNew ? 'Create account' : 'Sign in'}</h1>
            <p style={{ fontSize: 14, color: t.soft, margin: 0 }}>TLU Hour Tracker</p>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>Your name</label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Rishi" style={inputStyle()} />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>4-digit PIN</label>
            <input value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" type="password" maxLength={4} style={{ ...inputStyle(), letterSpacing: 8, fontSize: 22 }} onKeyDown={(e) => { if (e.key === 'Enter') { isNew ? handleCreate() : handleLogin(); } }} />
          </div>

          {isNew && (
            <>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>TLU releases this term</label>
                <input value={tluVal} onChange={(e) => setTluVal(e.target.value)} type="number" step="0.5" style={inputStyle()} />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>Hours per TLU</label>
                <input value={hptVal} onChange={(e) => setHptVal(e.target.value)} type="number" style={inputStyle()} />
                <p style={{ fontSize: 11, color: t.faint, margin: '4px 0 0' }}>OCFA: ~128 hrs (salary formula) · ~102 hrs (contact+prep)</p>
              </div>
            </>
          )}

          {error && <div style={{ background: t.dangerBg, color: t.danger, padding: '12px 16px', borderRadius: 12, fontSize: 14, marginBottom: 16, fontWeight: 500 }}>{error}</div>}

          <button onClick={isNew ? handleCreate : handleLogin} style={{ width: '100%', padding: '13px 24px', fontSize: 15, fontWeight: 600, fontFamily: FONT, borderRadius: 12, border: 'none', cursor: 'pointer', background: brand.magenta, color: '#fff', marginBottom: 10 }}>
            {isNew ? 'Create account' : 'Sign in'}
          </button>
          <button onClick={() => setIsNew(!isNew)} style={{ width: '100%', padding: '13px 24px', fontSize: 15, fontWeight: 600, fontFamily: FONT, borderRadius: 12, cursor: 'pointer', background: t.bg, color: t.text, border: `1.5px solid ${t.border}` }}>
            {isNew ? 'Back to sign in' : 'Create account'}
          </button>
        </div>
      </div>
    </div>
  );
}
