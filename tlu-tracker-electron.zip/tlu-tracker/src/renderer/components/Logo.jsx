import React from 'react';
import { FONT } from '../styles/theme';

export default function Logo({ isDark }) {
  const col = isDark ? '#EAEAE6' : '#FFFFFF';
  const pink = isDark ? '#FF4D7A' : '#E31B54';
  return (
    <svg width="220" height="36" viewBox="0 0 220 36" xmlns="http://www.w3.org/2000/svg">
      <text x="0" y="24" fontFamily="Georgia,Times,serif" fontSize="26" fontWeight="bold" fill={col} letterSpacing="3">HALL</text>
      <path d="M8 4 Q14 4 16 16 Q18 28 12 28 Q8 28 7 16 Z" fill={pink} opacity=".85" />
      <line x1="73" y1="6" x2="73" y2="30" stroke={col} strokeWidth=".5" opacity=".3" />
      <text x="80" y="15" fontFamily={FONT} fontSize="8.5" fontWeight="600" fill={col} letterSpacing="1.5" opacity=".7">SCHOOL OF BUSINESS</text>
      <text x="80" y="27" fontFamily={FONT} fontSize="8.5" fontWeight="600" fill={col} letterSpacing="1.5" opacity=".7">{'& ENTREPRENEURSHIP'}</text>
      <text x="195" y="27" fontFamily={FONT} fontSize="14" fontWeight="800" fill={pink}>OC</text>
    </svg>
  );
}
