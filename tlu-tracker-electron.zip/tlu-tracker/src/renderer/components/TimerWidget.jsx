import React, { useState, useEffect, useRef } from 'react';
import { brand, FONT } from '../styles/theme';
import { fmtTime } from '../utils/format';

export default function TimerWidget({ theme: t, isDark }) {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const [project, setProject] = useState('');
  const timerRef = useRef(null);
  const startRef = useRef(null);

  useEffect(() => {
    if (running) {
      startRef.current = Date.now() - seconds * 1000;
      timerRef.current = setInterval(() => {
        setSeconds(Math.floor((Date.now() - startRef.current) / 1000));
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [running]);

  const toggle = () => {
    if (running && seconds > 0) {
      // Send data to main process to save
      const hrs = Math.round((seconds / 3600) * 100) / 100;
      if (window.electronAPI && hrs >= 0.01) {
        window.electronAPI.sendTimerUpdate({ hours: hrs, project, action: 'save' });
      }
      setSeconds(0);
    }
    setRunning(!running);
  };

  const openDash = () => {
    if (window.electronAPI) window.electronAPI.openDashboard();
  };

  return (
    <div style={{
      width: 310, height: 170, borderRadius: 16,
      background: running ? t.tmOn : t.card,
      border: running ? 'none' : `1px solid ${t.border}`,
      padding: '20px 24px', fontFamily: FONT,
      WebkitAppRegion: 'drag', cursor: 'move',
      boxShadow: '0 8px 32px rgba(0,0,0,.2)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: running ? t.accent + '88' : t.faint }}>
          {running ? 'Recording' : 'TLU Tracker'}
        </div>
        <button onClick={openDash} style={{ WebkitAppRegion: 'no-drag', background: 'none', border: 'none', cursor: 'pointer', color: t.faint, fontSize: 10, fontFamily: FONT, fontWeight: 600 }}>
          Dashboard →
        </button>
      </div>

      <div style={{ fontSize: 40, fontWeight: 700, fontVariantNumeric: 'tabular-nums', letterSpacing: '-.03em', color: running ? t.tmTx : t.text, lineHeight: 1, marginBottom: 16, textAlign: 'center' }}>
        {fmtTime(seconds)}
      </div>

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', WebkitAppRegion: 'no-drag' }}>
        <input
          value={project}
          onChange={(e) => setProject(e.target.value)}
          placeholder="Project..."
          style={{
            flex: 1, padding: '8px 12px', fontSize: 13, fontFamily: FONT,
            border: `1px solid ${t.border}`, borderRadius: 8,
            background: t.card, color: t.text, outline: 'none',
          }}
        />
        <button
          onClick={toggle}
          style={{
            width: 44, height: 44, borderRadius: '50%', border: 'none', cursor: 'pointer',
            background: running ? '#fff' : brand.magenta,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: `0 2px 8px ${brand.magenta}44`,
          }}
        >
          {running
            ? <svg width="16" height="16" viewBox="0 0 24 24" fill={brand.magenta}><rect x="6" y="5" width="4" height="14" rx="1.5"/><rect x="14" y="5" width="4" height="14" rx="1.5"/></svg>
            : <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><polygon points="7,4 21,12 7,20"/></svg>
          }
        </button>
      </div>
    </div>
  );
}
