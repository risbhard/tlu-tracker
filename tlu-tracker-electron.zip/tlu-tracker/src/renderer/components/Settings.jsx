import React, { useState } from 'react';
import { brand, FONT } from '../styles/theme';

export default function Settings({ user, projects, onDeleteProject, theme: t, isElectron }) {
  const [tlu, setTlu] = useState(String(user.tlu_allocation || 1));
  const [hpt, setHpt] = useState(String(user.hours_per_tlu || 128));
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    if (isElectron) {
      await window.electronAPI.updateUser(user.id, {
        tluAllocation: parseFloat(tlu) || 1,
        hoursPerTlu: parseFloat(hpt) || 128,
      });
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const inputStyle = {
    width: '100%', boxSizing: 'border-box', padding: '13px 16px', fontSize: 17, fontFamily: FONT,
    border: `1.5px solid ${t.border}`, borderRadius: 12, background: t.card, color: t.text, outline: 'none',
  };

  return (
    <div style={{ background: t.card, borderRadius: 16, padding: 28, border: `1px solid ${t.border}`, maxWidth: 460 }}>
      <div style={{ fontSize: 16, fontWeight: 700, color: t.text, marginBottom: 20 }}>Settings</div>

      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>TLU releases this term</label>
        <input value={tlu} onChange={(e) => setTlu(e.target.value)} type="number" step="0.5" min="0.5" style={inputStyle} />
      </div>

      <div style={{ marginBottom: 20 }}>
        <label style={{ display: 'block', fontSize: 13, fontWeight: 600, color: t.soft, marginBottom: 6 }}>Hours per TLU</label>
        <input value={hpt} onChange={(e) => setHpt(e.target.value)} type="number" style={inputStyle} />
        <p style={{ fontSize: 11, color: t.faint, margin: '4px 0 0' }}>
          OCFA agreement: ~128 hrs (salary formula) · ~102 hrs (contact+prep)
        </p>
        <div style={{ fontSize: 11, color: t.faint, marginTop: 8, lineHeight: 1.6 }}>
          <strong style={{ fontWeight: 600, color: t.soft }}>Quick guide for business faculty:</strong><br />
          100 hrs — repeat course, mostly objective assessments<br />
          128 hrs — balanced default (salary formula)<br />
          150+ hrs — new prep, large class, heavy marking
        </div>
      </div>

      <div style={{ borderTop: `1px solid ${t.border}`, paddingTop: 16, marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: t.text, marginBottom: 8 }}>Projects</div>
        {projects.map((proj, idx) => (
          <div key={proj.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '7px 0', borderBottom: idx < projects.length - 1 ? `1px solid ${t.border}33` : 'none' }}>
            <span style={{ fontSize: 13, color: t.text }}>{proj.name}</span>
            {projects.length > 1 && (
              <button onClick={() => onDeleteProject(proj.id, proj.name)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: t.faint, fontSize: 12, fontFamily: FONT }}>
                Remove
              </button>
            )}
          </div>
        ))}
      </div>

      <button onClick={handleSave} style={{ width: '100%', padding: '13px 24px', fontSize: 15, fontWeight: 600, fontFamily: FONT, borderRadius: 12, border: 'none', cursor: 'pointer', background: brand.magenta, color: '#fff' }}>
        {saved ? '✓ Saved' : 'Save changes'}
      </button>
    </div>
  );
}
