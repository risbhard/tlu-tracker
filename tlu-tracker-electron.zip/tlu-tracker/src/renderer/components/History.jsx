import React from 'react';
import { brand, FONT } from '../styles/theme';
import { fmtHours } from '../utils/format';

export default function History({ entries, onDelete, onExport, theme: t }) {
  return (
    <div style={{ background: t.card, borderRadius: 16, padding: 22, border: `1px solid ${t.border}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <span style={{ fontSize: 16, fontWeight: 700, color: t.text }}>All entries ({entries.length})</span>
        {entries.length > 0 && (
          <button onClick={onExport} style={{ fontFamily: FONT, fontSize: 13, fontWeight: 600, padding: '10px 18px', borderRadius: 12, border: 'none', cursor: 'pointer', background: brand.magenta, color: '#fff' }}>
            Export CSV
          </button>
        )}
      </div>

      {entries.length === 0
        ? <p style={{ fontSize: 13, color: t.faint, textAlign: 'center', padding: '24px 0' }}>No entries yet.</p>
        : entries.map((entry) => (
          <div key={entry.id} style={{ display: 'flex', alignItems: 'center', padding: '12px 0', borderBottom: `1px solid ${t.border}33` }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: entry.method === 'timer' ? t.accent : brand.charcoalLight, marginRight: 12, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 15, fontWeight: 600, color: t.text }}>{fmtHours(entry.hours)} hrs</span>
                <span style={{ fontSize: 12, color: t.faint }}>{entry.date}</span>
              </div>
              <span style={{ fontSize: 13, color: t.soft }}>
                <strong style={{ fontWeight: 600, color: t.text }}>{entry.project}</strong> — {entry.notes || ''}
                <span style={{ marginLeft: 6, fontSize: 10, background: entry.method === 'timer' ? t.accentBg : t.bg, color: entry.method === 'timer' ? t.accentTx : t.soft, padding: '2px 8px', borderRadius: 6, fontWeight: 600 }}>
                  {entry.method}
                </span>
              </span>
            </div>
            <button onClick={() => onDelete(entry.id)} style={{ marginLeft: 8, background: 'none', border: 'none', cursor: 'pointer', color: t.faint, padding: 4, fontSize: 16 }}>✕</button>
          </div>
        ))
      }
    </div>
  );
}
