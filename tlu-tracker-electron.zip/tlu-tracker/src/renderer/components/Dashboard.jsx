import React, { useState, useEffect, useRef, useCallback } from 'react';
import { brand, FONT } from '../styles/theme';
import { fmtHours, fmtTime, getToday } from '../utils/format';
import Logo from './Logo';
import Timer from './Timer';
import ProgressRing from './ProgressRing';
import History from './History';
import Settings from './Settings';

export default function Dashboard({ user, onLogout, theme: t, isDark, onToggleTheme, isElectron }) {
  const [entries, setEntries] = useState([]);
  const [projects, setProjects] = useState([]);
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);
  const [project, setProject] = useState('');
  const [notes, setNotes] = useState('');
  const [mDate, setMDate] = useState(getToday());
  const [mHours, setMHours] = useState('');
  const [mProj, setMProj] = useState('');
  const [mNotes, setMNotes] = useState('');
  const [toast, setToast] = useState('');
  const [newProj, setNewProj] = useState('');
  const [showNewProj, setShowNewProj] = useState(false);
  const [tab, setTab] = useState('dash');
  const timerRef = useRef(null);
  const startRef = useRef(null);

  // Load data
  useEffect(() => {
    async function load() {
      if (isElectron) {
        const e = await window.electronAPI.getEntries(user.id);
        const p = await window.electronAPI.getProjects(user.id);
        setEntries(e);
        setProjects(p);
        if (p.length > 0) { setProject(p[0].name); setMProj(p[0].name); }
      } else {
        // Browser fallback with demo data
        setProjects([{ id: 1, name: 'ACBSP Accreditation' }, { id: 2, name: 'Course Development' }, { id: 3, name: 'Committee Work' }]);
        setProject('ACBSP Accreditation');
        setMProj('ACBSP Accreditation');
      }
    }
    load();
  }, [user.id, isElectron]);

  // Timer
  useEffect(() => {
    if (running) {
      startRef.current = Date.now() - seconds * 1000;
      timerRef.current = setInterval(() => {
        setSeconds(Math.floor((Date.now() - startRef.current) / 1000));
      }, 1000);
    } else {
      clearInterval(timerRef.current);
    }
    return () => clearInterval(timerRef.current);
  }, [running]);

  const hpt = user.hours_per_tlu || 128;
  const tluAlloc = user.tlu_allocation || 1;
  const totalHrs = tluAlloc * hpt;
  const usedHrs = entries.reduce((acc, e) => acc + e.hours, 0);
  const remaining = totalHrs - usedHrs;

  const flash = (msg) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const handleTimerToggle = async () => {
    if (running) {
      const hrs = Math.round((seconds / 3600) * 100) / 100;
      if (hrs >= 0.01) {
        const entry = { userId: user.id, date: getToday(), hours: hrs, project, notes: notes.trim() || 'Timer session', method: 'timer' };
        if (isElectron) {
          const saved = await window.electronAPI.addEntry(entry);
          setEntries((prev) => [saved, ...prev]);
        } else {
          setEntries((prev) => [{ id: Date.now(), ...entry, created_at: new Date().toISOString() }, ...prev]);
        }
        flash('Saved ' + fmtHours(hrs) + ' hrs');
      }
      setSeconds(0);
      setNotes('');
    }
    setRunning(!running);
  };

  const addManual = async () => {
    const hrs = parseFloat(mHours);
    if (!hrs || hrs <= 0) return;
    const entry = { userId: user.id, date: mDate, hours: hrs, project: mProj, notes: mNotes.trim() || 'Manual entry', method: 'manual' };
    if (isElectron) {
      const saved = await window.electronAPI.addEntry(entry);
      setEntries((prev) => [saved, ...prev]);
    } else {
      setEntries((prev) => [{ id: Date.now(), ...entry, created_at: new Date().toISOString() }, ...prev]);
    }
    flash('Added ' + fmtHours(hrs) + ' hrs');
    setMHours('');
    setMNotes('');
  };

  const deleteEntry = async (entryId) => {
    if (isElectron) await window.electronAPI.deleteEntry(entryId);
    setEntries((prev) => prev.filter((e) => e.id !== entryId));
    flash('Deleted');
  };

  const addProject = async () => {
    const name = newProj.trim();
    if (!name || projects.find((p) => p.name === name)) return;
    if (isElectron) {
      const result = await window.electronAPI.addProject(user.id, name);
      if (!result.error) setProjects((prev) => [...prev, result]);
    } else {
      setProjects((prev) => [...prev, { id: Date.now(), name }]);
    }
    setNewProj('');
    setShowNewProj(false);
  };

  const deleteProject = async (projId, projName) => {
    if (isElectron) await window.electronAPI.deleteProject(projId);
    setProjects((prev) => prev.filter((p) => p.id !== projId));
    if (project === projName && projects.length > 1) {
      const next = projects.find((p) => p.id !== projId);
      if (next) setProject(next.name);
    }
  };

  const exportCSV = () => {
    const rows = [['Date', 'Hours', 'Project', 'Notes', 'Method']];
    [...entries].sort((a, b) => a.date.localeCompare(b.date)).forEach((e) => {
      rows.push([e.date, e.hours, e.project, '"' + (e.notes || '') + '"', e.method]);
    });
    const blob = new Blob([rows.map((r) => r.join(',')).join('\n')], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'TLU_' + user.name + '_' + getToday() + '.csv';
    link.click();
    flash('Exported');
  };

  const sorted = [...entries].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  const byProject = {};
  entries.forEach((e) => { byProject[e.project] = (byProject[e.project] || 0) + e.hours; });

  const TabBtn = ({ id, label }) => (
    <button onClick={() => setTab(id)} style={{ fontFamily: FONT, fontSize: 14, fontWeight: 600, padding: '10px 18px', borderRadius: 10, border: 'none', cursor: 'pointer', background: tab === id ? t.accentBg : 'transparent', color: tab === id ? t.accentTx : t.faint }}>
      {label}
    </button>
  );

  const inputStyle = { width: '100%', boxSizing: 'border-box', padding: '10px 12px', fontSize: 14, fontFamily: FONT, border: `1.5px solid ${t.border}`, borderRadius: 12, background: t.card, color: t.text, outline: 'none' };

  return (
    <div style={{ minHeight: '100vh', background: t.bg, fontFamily: FONT }}>
      {/* Header */}
      <div style={{ background: t.hdr, padding: '12px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10, WebkitAppRegion: 'drag' }}>
        <Logo isDark={isDark} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, WebkitAppRegion: 'no-drag' }}>
          {isElectron && (
            <button onClick={() => window.electronAPI.toggleTimerWidget()} style={{ fontFamily: FONT, fontSize: 12, fontWeight: 600, padding: '8px 16px', borderRadius: 10, border: '1px solid rgba(255,255,255,.15)', background: 'transparent', color: t.hdrSoft, cursor: 'pointer' }}>
              Mini Timer
            </button>
          )}
          <button onClick={onToggleTheme} style={{ width: 38, height: 38, borderRadius: 10, border: 'none', cursor: 'pointer', background: isDark ? 'rgba(255,255,255,.08)' : 'rgba(255,255,255,.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {isDark
              ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FCD34D" strokeWidth="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
              : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>
            }
          </button>
          <button onClick={onLogout} style={{ fontFamily: FONT, fontSize: 12, fontWeight: 600, padding: '8px 16px', borderRadius: 10, border: '1px solid rgba(255,255,255,.15)', background: 'transparent', color: t.hdrSoft, cursor: 'pointer' }}>Sign out</button>
        </div>
      </div>

      {/* Welcome bar */}
      <div style={{ background: t.hdr, padding: '0 24px 18px' }}>
        <div style={{ maxWidth: 820, margin: '0 auto' }}>
          <p style={{ fontSize: 20, fontWeight: 700, color: t.hdrTx, margin: '0 0 2px' }}>Welcome, {user.name}</p>
          <p style={{ fontSize: 13, color: t.hdrSoft, margin: 0 }}>{tluAlloc} TLU{tluAlloc !== 1 ? 's' : ''} · {fmtHours(remaining)} of {fmtHours(totalHrs)} hrs remaining</p>
        </div>
      </div>

      <div style={{ maxWidth: 820, margin: '0 auto', padding: '20px 16px' }}>
        {/* Toast */}
        {toast && <div style={{ position: 'fixed', bottom: 28, left: '50%', transform: 'translateX(-50%)', background: brand.charcoalDark, color: '#fff', padding: '13px 26px', borderRadius: 14, fontSize: 15, fontWeight: 600, zIndex: 100, boxShadow: '0 6px 20px rgba(0,0,0,.2)', fontFamily: FONT }}>{toast}</div>}

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 20, background: t.card, borderRadius: 14, padding: 4, border: `1px solid ${t.border}` }}>
          <TabBtn id="dash" label="Dashboard" />
          <TabBtn id="history" label="History" />
          <TabBtn id="settings" label="Settings" />
        </div>

        {tab === 'dash' && (
          <>
            {/* Project selector + Timer */}
            <div style={{ marginBottom: 20 }}>
              <div style={{ display: 'flex', gap: 10, marginBottom: 12 }}>
                <select value={project} onChange={(e) => setProject(e.target.value)} style={{ ...inputStyle, flex: 1, fontSize: 16, padding: '13px 16px' }}>
                  {projects.map((p) => <option key={p.id} value={p.name}>{p.name}</option>)}
                </select>
                <button onClick={() => setShowNewProj(!showNewProj)} style={{ fontFamily: FONT, fontSize: 13, fontWeight: 600, padding: '13px 16px', borderRadius: 12, cursor: 'pointer', background: t.bg, color: t.text, border: `1.5px solid ${t.border}` }}>+ Project</button>
              </div>
              {showNewProj && (
                <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                  <input value={newProj} onChange={(e) => setNewProj(e.target.value)} placeholder="Project name" style={inputStyle} onKeyDown={(e) => { if (e.key === 'Enter') addProject(); }} />
                  <button onClick={addProject} style={{ fontFamily: FONT, fontSize: 15, fontWeight: 600, padding: '13px 18px', borderRadius: 12, border: 'none', cursor: 'pointer', background: brand.magenta, color: '#fff' }}>Add</button>
                </div>
              )}
              {running && <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What are you working on?" style={{ ...inputStyle, marginBottom: 12, fontSize: 16, padding: '13px 16px' }} />}
              <Timer seconds={seconds} running={running} onToggle={handleTimerToggle} project={project} theme={t} />
            </div>

            {/* Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14, marginBottom: 20 }}>
              <div style={{ background: t.card, borderRadius: 16, padding: 20, border: `1px solid ${t.border}`, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={{ position: 'relative', marginBottom: 6 }}>
                  <ProgressRing used={usedHrs} total={totalHrs} theme={t} />
                  <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 24, fontWeight: 700, color: t.text }}>{totalHrs > 0 ? Math.round((usedHrs / totalHrs) * 100) : 0}%</span>
                    <span style={{ fontSize: 11, color: t.faint }}>used</span>
                  </div>
                </div>
                <span style={{ fontSize: 12, color: t.soft }}>{fmtHours(usedHrs)} / {fmtHours(totalHrs)}</span>
              </div>
              <div style={{ background: t.accentBg, borderRadius: 16, padding: 20 }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.06em', textTransform: 'uppercase', color: t.accentTx, marginBottom: 6 }}>Remaining</div>
                <div style={{ fontSize: 28, fontWeight: 700, color: t.accentTx }}>{fmtHours(Math.max(remaining, 0))}</div>
                <div style={{ fontSize: 12, color: t.accentTx + '99' }}>hours left</div>
              </div>
              <div style={{ background: t.card, borderRadius: 16, padding: 20, border: `1px solid ${t.border}` }}>
                <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.06em', textTransform: 'uppercase', color: t.faint, marginBottom: 6 }}>Logged</div>
                <div style={{ fontSize: 28, fontWeight: 700, color: t.text }}>{entries.length}</div>
                <div style={{ fontSize: 12, color: t.soft }}>entries</div>
              </div>
            </div>

            {/* Manual entry + By project */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
              {/* Manual */}
              <div style={{ background: t.card, borderRadius: 16, padding: 22, border: `1px solid ${t.border}` }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: t.text, marginBottom: 14 }}>+ Add hours manually</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
                  <div>
                    <label style={{ display: 'block', fontSize: 11, color: t.faint, marginBottom: 4, fontWeight: 600 }}>Date</label>
                    <input type="date" value={mDate} onChange={(e) => setMDate(e.target.value)} style={inputStyle} />
                  </div>
                  <div>
                    <label style={{ display: 'block', fontSize: 11, color: t.faint, marginBottom: 4, fontWeight: 600 }}>Hours</label>
                    <input type="number" value={mHours} onChange={(e) => setMHours(e.target.value)} placeholder="2.5" step="0.25" style={inputStyle} />
                  </div>
                </div>
                <div style={{ marginBottom: 10 }}>
                  <label style={{ display: 'block', fontSize: 11, color: t.faint, marginBottom: 4, fontWeight: 600 }}>Project</label>
                  <select value={mProj} onChange={(e) => setMProj(e.target.value)} style={inputStyle}>
                    {projects.map((p) => <option key={p.id} value={p.name}>{p.name}</option>)}
                  </select>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'block', fontSize: 11, color: t.faint, marginBottom: 4, fontWeight: 600 }}>Notes</label>
                  <input value={mNotes} onChange={(e) => setMNotes(e.target.value)} placeholder="Optional" style={inputStyle} />
                </div>
                <button onClick={addManual} style={{ width: '100%', padding: '13px 24px', fontSize: 15, fontWeight: 600, fontFamily: FONT, borderRadius: 12, border: 'none', cursor: 'pointer', background: brand.magenta, color: '#fff' }}>Save hours</button>
              </div>

              {/* By project */}
              <div style={{ background: t.card, borderRadius: 16, padding: 22, border: `1px solid ${t.border}` }}>
                <div style={{ fontSize: 14, fontWeight: 700, color: t.text, marginBottom: 14 }}>By project</div>
                {Object.keys(byProject).length === 0
                  ? <p style={{ fontSize: 13, color: t.faint, textAlign: 'center', padding: '16px 0' }}>No entries yet</p>
                  : Object.entries(byProject).sort((a, b) => b[1] - a[1]).map(([projName, hrs]) => (
                    <div key={projName} style={{ marginBottom: 12 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ fontSize: 13, color: t.text }}>{projName}</span>
                        <span style={{ fontSize: 13, fontWeight: 700, color: t.accent }}>{fmtHours(hrs)}</span>
                      </div>
                      <div style={{ height: 4, borderRadius: 2, background: t.border }}>
                        <div style={{ height: '100%', borderRadius: 2, background: t.accent, width: `${Math.min((hrs / totalHrs) * 100, 100)}%`, transition: 'width .5s' }} />
                      </div>
                    </div>
                  ))
                }
                {entries.length > 0 && (
                  <button onClick={exportCSV} style={{ width: '100%', marginTop: 8, padding: '13px 24px', fontSize: 13, fontWeight: 600, fontFamily: FONT, borderRadius: 12, cursor: 'pointer', background: t.bg, color: t.text, border: `1.5px solid ${t.border}` }}>Export CSV</button>
                )}
              </div>
            </div>

            {/* Recent entries */}
            <div style={{ background: t.card, borderRadius: 16, padding: 22, border: `1px solid ${t.border}` }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: t.text, marginBottom: 14 }}>Recent entries</div>
              {sorted.length === 0
                ? <p style={{ fontSize: 13, color: t.faint, textAlign: 'center', padding: '20px 0' }}>Start the timer or add hours to begin.</p>
                : sorted.slice(0, 5).map((entry) => (
                  <div key={entry.id} style={{ display: 'flex', alignItems: 'center', padding: '11px 0', borderBottom: `1px solid ${t.border}33` }}>
                    <div style={{ width: 6, height: 6, borderRadius: '50%', background: entry.method === 'timer' ? t.accent : brand.charcoalLight, marginRight: 12, flexShrink: 0 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ fontSize: 14, fontWeight: 600, color: t.text }}>{fmtHours(entry.hours)} hrs</span>
                        <span style={{ fontSize: 11, color: t.faint }}>{entry.date}</span>
                      </div>
                      <span style={{ fontSize: 12, color: t.soft }}>{entry.project} — {entry.notes}</span>
                    </div>
                    <button onClick={() => deleteEntry(entry.id)} style={{ marginLeft: 8, background: 'none', border: 'none', cursor: 'pointer', color: t.faint, padding: 4, fontSize: 14 }}>✕</button>
                  </div>
                ))
              }
              {sorted.length > 5 && (
                <button onClick={() => setTab('history')} style={{ width: '100%', marginTop: 8, padding: '13px', fontFamily: FONT, fontSize: 14, fontWeight: 600, background: 'transparent', border: 'none', cursor: 'pointer', color: t.accent }}>View all →</button>
              )}
            </div>
          </>
        )}

        {tab === 'history' && <History entries={sorted} onDelete={deleteEntry} onExport={exportCSV} theme={t} />}
        {tab === 'settings' && <Settings user={user} projects={projects} onDeleteProject={deleteProject} theme={t} isElectron={isElectron} />}
      </div>
    </div>
  );
}
