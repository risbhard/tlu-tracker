import React from 'react';
import { brand } from '../styles/theme';
import { fmtTime } from '../utils/format';

export default function Timer({ seconds, running, onToggle, project, theme: t }) {
  return (
    <div style={{
      background: running ? t.tmOn : t.card,
      borderRadius: 20, padding: '28px 32px',
      border: running ? 'none' : `1px solid ${t.border}`,
      boxShadow: t.shadow, transition: 'all .4s ease',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.1em', textTransform: 'uppercase', color: running ? t.accent + '88' : t.faint, marginBottom: 6 }}>
            {running ? 'Recording' : 'Ready'}
          </div>
          <div style={{ fontSize: 48, fontWeight: 700, fontVariantNumeric: 'tabular-nums', letterSpacing: '-.03em', color: running ? t.tmTx : t.text, lineHeight: 1 }}>
            {fmtTime(seconds)}
          </div>
          {project && <div style={{ fontSize: 13, color: running ? t.accent + '55' : t.faint, marginTop: 8 }}>{project}</div>}
        </div>
        <button
          onClick={onToggle}
          style={{
            width: 76, height: 76, borderRadius: '50%', border: 'none', cursor: 'pointer',
            background: running ? '#fff' : brand.magenta,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: running ? t.shadow : `0 4px 16px ${brand.magenta}44`,
            transition: 'transform .12s',
          }}
          onMouseDown={(e) => { e.currentTarget.style.transform = 'scale(.92)'; }}
          onMouseUp={(e) => { e.currentTarget.style.transform = 'scale(1)'; }}
        >
          {running
            ? <svg width="22" height="22" viewBox="0 0 24 24" fill={brand.magenta}><rect x="6" y="5" width="4" height="14" rx="1.5"/><rect x="14" y="5" width="4" height="14" rx="1.5"/></svg>
            : <svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><polygon points="7,4 21,12 7,20"/></svg>
          }
        </button>
      </div>
      {running && (
        <div style={{ height: 3, borderRadius: 2, background: t.accent + '22', marginTop: 20, overflow: 'hidden' }}>
          <div style={{ height: '100%', borderRadius: 2, background: t.accent, width: `${Math.min((seconds / 3600) * 100, 100)}%`, transition: 'width 1s linear' }} />
        </div>
      )}
    </div>
  );
}
