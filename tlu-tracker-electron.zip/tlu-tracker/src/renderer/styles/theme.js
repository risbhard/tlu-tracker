// Hall School of Business & Entrepreneurship brand colors
export const brand = {
  magenta: '#E31B54',
  charcoal: '#3C3C3C',
  charcoalLight: '#5A5A5A',
  charcoalDark: '#2A2A2A',
};

export const themes = {
  light: {
    bg: '#F7F5F2',
    card: '#FFFFFF',
    text: '#1C1C1A',
    soft: '#6E6E6A',
    faint: '#A3A39E',
    border: '#E5E2DC',
    accent: brand.magenta,
    accentBg: '#FDE8EF',
    accentTx: '#B8133F',
    danger: '#DC2626',
    dangerBg: '#FEF2F2',
    hdr: brand.charcoal,
    hdrTx: '#FFFFFF',
    hdrSoft: 'rgba(255,255,255,.6)',
    tmOn: brand.charcoalDark,
    tmTx: brand.magenta,
    shadow: '0 1px 4px rgba(0,0,0,.06)',
  },
  dark: {
    bg: '#111110',
    card: '#1C1C1A',
    text: '#EAEAE6',
    soft: '#8E8E88',
    faint: '#5A5A56',
    border: '#2D2D2A',
    accent: '#FF4D7A',
    accentBg: 'rgba(255,77,122,.12)',
    accentTx: '#FF4D7A',
    danger: '#F87171',
    dangerBg: 'rgba(248,113,113,.12)',
    hdr: '#0C0C0B',
    hdrTx: '#EAEAE6',
    hdrSoft: 'rgba(234,234,230,.45)',
    tmOn: '#1A0A10',
    tmTx: '#FF4D7A',
    shadow: '0 1px 4px rgba(0,0,0,.3)',
  },
};

export const FONT = '"DM Sans","Segoe UI",system-ui,sans-serif';
