const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // User operations
  getUsers: () => ipcRenderer.invoke('db:getUsers'),
  createUser: (user) => ipcRenderer.invoke('db:createUser', user),
  updateUser: (id, updates) => ipcRenderer.invoke('db:updateUser', id, updates),
  loginUser: (name, pin) => ipcRenderer.invoke('db:loginUser', name, pin),

  // Entry operations
  getEntries: (userId) => ipcRenderer.invoke('db:getEntries', userId),
  addEntry: (entry) => ipcRenderer.invoke('db:addEntry', entry),
  deleteEntry: (id) => ipcRenderer.invoke('db:deleteEntry', id),

  // Project operations
  getProjects: (userId) => ipcRenderer.invoke('db:getProjects', userId),
  addProject: (userId, name) => ipcRenderer.invoke('db:addProject', userId, name),
  deleteProject: (id) => ipcRenderer.invoke('db:deleteProject', id),

  // Window controls
  toggleTimerWidget: () => ipcRenderer.send('toggle-timer-widget'),
  openDashboard: () => ipcRenderer.send('open-dashboard'),

  // Timer sync between windows
  onTimerUpdate: (callback) => ipcRenderer.on('timer-update', (_, data) => callback(data)),
  sendTimerUpdate: (data) => ipcRenderer.send('timer-update', data),
});
