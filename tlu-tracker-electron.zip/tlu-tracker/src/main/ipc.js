const { ipcMain } = require('electron');

function registerIpcHandlers(db) {
  // ── Users ──
  ipcMain.handle('db:getUsers', () => {
    return db.prepare('SELECT id, name, hours_per_tlu, tlu_allocation, created_at FROM users').all();
  });

  ipcMain.handle('db:loginUser', (_, name, pin) => {
    const user = db.prepare('SELECT id, name, hours_per_tlu, tlu_allocation FROM users WHERE LOWER(name) = LOWER(?) AND pin = ?').get(name, pin);
    return user || null;
  });

  ipcMain.handle('db:createUser', (_, { name, pin, hoursPerTlu, tluAllocation }) => {
    try {
      const result = db.prepare('INSERT INTO users (name, pin, hours_per_tlu, tlu_allocation) VALUES (?, ?, ?, ?)').run(name, pin, hoursPerTlu || 128, tluAllocation || 1);
      const userId = result.lastInsertRowid;
      db.prepare('INSERT INTO projects (user_id, name) VALUES (?, ?)').run(userId, 'General Project Work');
      return { id: userId, name, hours_per_tlu: hoursPerTlu || 128, tlu_allocation: tluAllocation || 1 };
    } catch (err) {
      if (err.message.includes('UNIQUE')) return { error: 'Name already taken' };
      return { error: err.message };
    }
  });

  ipcMain.handle('db:updateUser', (_, id, updates) => {
    const fields = [];
    const values = [];
    if (updates.hoursPerTlu !== undefined) { fields.push('hours_per_tlu = ?'); values.push(updates.hoursPerTlu); }
    if (updates.tluAllocation !== undefined) { fields.push('tlu_allocation = ?'); values.push(updates.tluAllocation); }
    if (updates.pin !== undefined) { fields.push('pin = ?'); values.push(updates.pin); }
    if (fields.length === 0) return false;
    values.push(id);
    db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);
    return true;
  });

  // ── Entries ──
  ipcMain.handle('db:getEntries', (_, userId) => {
    return db.prepare('SELECT * FROM entries WHERE user_id = ? ORDER BY date DESC, created_at DESC').all(userId);
  });

  ipcMain.handle('db:addEntry', (_, { userId, date, hours, project, notes, method }) => {
    const result = db.prepare('INSERT INTO entries (user_id, date, hours, project, notes, method) VALUES (?, ?, ?, ?, ?, ?)').run(userId, date, hours, project, notes || '', method || 'manual');
    return {
      id: result.lastInsertRowid,
      user_id: userId,
      date, hours, project,
      notes: notes || '',
      method: method || 'manual',
      created_at: new Date().toISOString(),
    };
  });

  ipcMain.handle('db:deleteEntry', (_, id) => {
    db.prepare('DELETE FROM entries WHERE id = ?').run(id);
    return true;
  });

  // ── Projects ──
  ipcMain.handle('db:getProjects', (_, userId) => {
    return db.prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY name').all(userId);
  });

  ipcMain.handle('db:addProject', (_, userId, name) => {
    try {
      const result = db.prepare('INSERT INTO projects (user_id, name) VALUES (?, ?)').run(userId, name);
      return { id: result.lastInsertRowid, user_id: userId, name };
    } catch (err) {
      if (err.message.includes('UNIQUE')) return { error: 'Project already exists' };
      return { error: err.message };
    }
  });

  ipcMain.handle('db:deleteProject', (_, id) => {
    db.prepare('DELETE FROM projects WHERE id = ?').run(id);
    return true;
  });
}

module.exports = { registerIpcHandlers };
