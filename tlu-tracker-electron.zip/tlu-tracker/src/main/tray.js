const { Tray, Menu, nativeImage } = require('electron');
const path = require('path');

let tray = null;

function createTray({ onShowDashboard, onToggleTimer, onQuit }) {
  // Create a simple 16x16 tray icon (clock shape)
  // In production, replace with a proper .png icon
  const iconPath = path.join(__dirname, '../../public/tray-icon.png');

  // Fallback: create a simple icon programmatically
  let icon;
  try {
    icon = nativeImage.createFromPath(iconPath);
    if (icon.isEmpty()) throw new Error('empty');
  } catch {
    // Create a minimal 16x16 icon as fallback
    icon = nativeImage.createEmpty();
  }

  tray = new Tray(icon);
  tray.setToolTip('TLU Hour Tracker');

  const contextMenu = Menu.buildFromTemplate([
    { label: 'Open Dashboard', click: onShowDashboard },
    { label: 'Toggle Timer Widget', click: onToggleTimer },
    { type: 'separator' },
    { label: 'Quit', click: onQuit },
  ]);

  tray.setContextMenu(contextMenu);

  // Click tray icon to show dashboard
  tray.on('click', onShowDashboard);

  return tray;
}

module.exports = { createTray };
