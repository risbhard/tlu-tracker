const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage } = require('electron');
const path = require('path');
const { setupDatabase } = require('./database');
const { registerIpcHandlers } = require('./ipc');
const { createTray } = require('./tray');

const isDev = !app.isPackaged;

let mainWindow = null;
let timerWindow = null;
let tray = null;
let db = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 900,
    height: 700,
    minWidth: 700,
    minHeight: 500,
    title: 'TLU Hour Tracker',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(__dirname, '../../dist/index.html'));
  }

  mainWindow.on('closed', () => { mainWindow = null; });
}

function createTimerWindow() {
  timerWindow = new BrowserWindow({
    width: 320,
    height: 180,
    resizable: false,
    frame: false,
    transparent: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  if (isDev) {
    timerWindow.loadURL('http://localhost:5173/#/timer-widget');
  } else {
    timerWindow.loadFile(path.join(__dirname, '../../dist/index.html'), { hash: '/timer-widget' });
  }

  timerWindow.on('closed', () => { timerWindow = null; });
}

app.whenReady().then(() => {
  // Initialize database
  db = setupDatabase();

  // Register IPC handlers
  registerIpcHandlers(db);

  // Create windows
  createMainWindow();

  // Create system tray
  tray = createTray({
    onShowDashboard: () => {
      if (mainWindow) {
        mainWindow.show();
        mainWindow.focus();
      } else {
        createMainWindow();
      }
    },
    onToggleTimer: () => {
      if (timerWindow) {
        timerWindow.close();
        timerWindow = null;
      } else {
        createTimerWindow();
      }
    },
    onQuit: () => app.quit(),
  });

  // IPC: toggle timer widget from renderer
  ipcMain.on('toggle-timer-widget', () => {
    if (timerWindow) {
      timerWindow.close();
      timerWindow = null;
    } else {
      createTimerWindow();
    }
  });

  ipcMain.on('open-dashboard', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    } else {
      createMainWindow();
    }
  });
});

app.on('window-all-closed', () => {
  // Keep running in tray on macOS
  if (process.platform !== 'darwin') {
    // Don't quit — keep tray alive
  }
});

app.on('activate', () => {
  if (!mainWindow) createMainWindow();
});

app.on('before-quit', () => {
  if (db) db.close();
});
