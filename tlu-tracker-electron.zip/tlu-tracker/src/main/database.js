const Database = require('better-sqlite3');
const path = require('path');
const { app } = require('electron');

function setupDatabase() {
  const dbPath = path.join(app.getPath('userData'), 'tlu-tracker.db');
  const db = new Database(dbPath);

  // Enable WAL mode for better performance
  db.pragma('journal_mode = WAL');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      pin TEXT NOT NULL,
      hours_per_tlu REAL DEFAULT 128,
      tlu_allocation REAL DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      UNIQUE(user_id, name)
    );

    CREATE TABLE IF NOT EXISTS entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      date TEXT NOT NULL,
      hours REAL NOT NULL,
      project TEXT NOT NULL,
      notes TEXT DEFAULT '',
      method TEXT DEFAULT 'manual',
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_entries_user ON entries(user_id);
    CREATE INDEX IF NOT EXISTS idx_entries_date ON entries(date);
    CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
  `);

  // Seed a demo user if empty
  const count = db.prepare('SELECT COUNT(*) as c FROM users').get();
  if (count.c === 0) {
    const insertUser = db.prepare('INSERT INTO users (name, pin, hours_per_tlu, tlu_allocation) VALUES (?, ?, ?, ?)');
    const insertProject = db.prepare('INSERT INTO projects (user_id, name) VALUES (?, ?)');

    const result = insertUser.run('Rishi', '1234', 128, 1);
    const userId = result.lastInsertRowid;

    insertProject.run(userId, 'ACBSP Accreditation');
    insertProject.run(userId, 'Course Development');
    insertProject.run(userId, 'Committee Work');
  }

  return db;
}

module.exports = { setupDatabase };
