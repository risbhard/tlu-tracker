# TLU Hour Tracker

A desktop application for faculty at the Hall School of Business & Entrepreneurship (Okanagan College) to track TLU release time hours.

## Features

- **Desktop timer widget** — small always-on-top window with start/stop, sits in system tray
- **Full dashboard** — progress ring, project breakdown, history, CSV export
- **Dark/light theme** — Hall School branding (magenta + charcoal)
- **Multi-user** — name + PIN login, each user has their own data
- **Configurable** — set your own hours-per-TLU (default 128, per OCFA agreement)
- **Offline-first** — SQLite database, no internet required

## Tech Stack

- **Electron** — cross-platform desktop app
- **React** — UI framework
- **SQLite (better-sqlite3)** — local database
- **Vite** — build tooling

## Quick Start

```bash
# Install dependencies
npm install

# Run in development mode
npm run dev

# Build for production
npm run build

# Package as installer
npm run package
```

## Architecture

```
src/
  main/           # Electron main process
    main.js       # App entry, creates windows
    tray.js       # System tray icon + mini timer
    database.js   # SQLite database layer
    ipc.js        # IPC handlers (main <-> renderer)
  renderer/       # React UI
    App.jsx       # Root component with routing
    components/   # UI components
      Login.jsx
      Dashboard.jsx
      Timer.jsx
      TimerWidget.jsx   # Mini floating timer
      History.jsx
      Settings.jsx
      ProgressRing.jsx
    styles/
      theme.js    # Brand colors + light/dark tokens
    utils/
      format.js   # Time/number formatting helpers
public/
  index.html      # HTML entry point
```

## TLU Hours Reference (OCFA Collective Agreement)

| Method | Hours/TLU | Source |
|--------|-----------|--------|
| Salary formula | ~128 hrs | Art. 37.2.2 |
| Contact + prep (1:1) | ~102 hrs | Art. 19.3 + 19.6 |
| Non-instructional equiv. | ~163 hrs | Art. 14.2.1 (adjusted 30/35) |

Default is 128 hours. Each user can configure their own value.

## For Business Faculty

Standard 3+1 structure (3 hrs teaching + 1 hr student interaction/week × 17 weeks = 68 contact hrs).
With prep and marking, typical range is 100–150 hours per TLU depending on course.

## License

Internal tool — Okanagan College, Hall School of Business & Entrepreneurship
