# Public Assets

Place your icons here:
- `icon.png` — App icon (256x256 or larger)
- `tray-icon.png` — System tray icon (16x16 or 32x32)
- `hall-logo-light.png` — Hall School logo for light backgrounds
- `hall-logo-dark.png` — Hall School logo for dark backgrounds

The uploaded logo files from the project chat can be used here.
